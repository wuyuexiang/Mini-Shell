/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include "order_judge.h"
#include "en_fou.h"
#include "redirect.h"
#include "my_pipe.h"
#include "record_history.h"
#include "keypress.h"
#include "jobs.h"

/*!
    \brief Rotina principal do programa 
    \return Retorna 0 no fechamento do programa   
    \var char buf_pwd[100]
      \brief Armazena o PATH
    \var char cmd_buf[200]
      \Armazena a entrada do teclado
    \var char *erg[100]
      \brief Armazena os argumentos
    \var char *cmd_name
      \brief Para os programas previamente instalados
    \var int bg_flag
      \brief Flag que indica se o processo vai rodar no background
    \var int exe_flag
      \brief Flag que indica se o arquivo é um excecutável
*/
int main(int argc,char *argv[])
{
    sig_init(); /*! Inicializa os sinais, tais como Ctrl_z e Ctrl_c. */
    init_environ(); /*! Define o ambiente. */
    while(1)
    {
        pid_t pid;
        int i=0;
        int status;
        char buf_pwd[100]="";
        char cmd_buf[200]="";
        char *erg[100]={NULL};

        char *cmd_name=NULL;
        int bg_flag=0;
        int exe_flag=0;

        /// Imprime o caminho atual.
        printf("MiniShell@WU_GUSTAVO %s:~$ ",getcwd(buf_pwd, 100));
        /// Lê do teclado e armazena em cmd_buf.
        get_cmd(cmd_buf,sizeof(cmd_buf));
                /// Se for rodar no background, remove '&' de cmd_buf e seta flag de bg para 1.
                if(strchr(cmd_buf,'&')!=0)
                {
                    bg_flag=1;
                    cmd_buf[strlen(cmd_buf)-2]='\0';
                }
                /// Se for um programa executável, seta a flag de executável para 1.
                if((cmd_buf[0]=='.')&&(cmd_buf[1]=='/'))
                {
                    exe_flag=1;
                }
        /// Verifica se há pipe.
        if(my_pipe(cmd_buf))
            continue;
        /// Coloca o conteúdo de cmd_buf como argumentos da chamada.
        redirect(cmd_buf,erg);
        /// Se for um comando interno chama reset_io.
        if(fun_shell(i,erg))
        {
            reset_io();
            continue;
        }
        /// Se for um comando implementado, dá fork no processo.
        if((cmd_name=is_founded(erg[0]))||exe_flag==1)
        {
            exe_flag=0;
            pid=fork();
            if(pid < 0)
            {
                /// Se houver erro ao criar processo filho, printa uma mensagem.
                perror("fork");
                exit(1);
            }
            else if(pid==0)
            {
                if(execv(cmd_name,erg)<0 && execv(erg[0],erg)<0)
                /// Trata erros dos programas executáveis, acesso não permitido, etc.                
                switch(errno){
                case ENOENT:
                    printf("COMMAND OR FILENAME NOT FOUND\n");
                    break;
                case EACCES:
                    printf("YOU DO NOT HAVE RIGHT TO ACCESS\n");
                    break;
                            default:
                                    printf("SOME ERROR HAPPENED IN EXEC\n");}
                                exit(3);
            }
            else
            {
                int status;
                /// Se não for background, espera o término do  processo filho.
                if(bg_flag==0)
                {
                    waitpid(pid,&status,WUNTRACED);
                }
                else
                {
                    /// Se for background, seta o flag de bg para 0 e o status para 123.
                    bg_flag=0;
                    status=123;
                }
                /// Adiciona o job na lista dos jobs.
                add_job_node(status, pid, erg[0]);
            }
        }
        /// Senão, exibe mensagem de "Comando inválido".
        else
        {
            printf("command %s not found!\n",erg[0]);
            /// Limpas os buffers de E/S
            reset_io();
            /// Espera o processo terminar
            waitpid(pid,&status,0);                              
        }
    }
    return 0;
}
