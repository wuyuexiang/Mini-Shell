/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

/* Programa principal */

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>
#include<fcntl.h>
#include<errno.h>
#include<signal.h>
#include"order_judge.h"
#include"en_fou.h"
#include"redirect.h"
#include"my_pipe.h"
#include"record_history.h"
#include"keypress.h"
#include"jobs.h"



int main(int argc,char *argv[])
{
    sig_init(); /* inicializa os sinais, tais como Ctrl_z e Ctrl_c */
	init_environ(); /* define o ambiente */
	while(1)
	{
		pid_t pid;
		int i=0;
		int status;
		char buf_pwd[100]=""; /* armazena o PATH */
		char cmd_buf[200]=""; /* armazena a entrada do teclado */
		char *erg[100]={NULL}; /* armazena os argumentos */
		char *cmd_name=NULL;//para os programas instalados
        int bg_flag=0; /* flag que indica se o processo vai rodar no background */
        int exe_flag=0; /* flag que indica se o arquivo é um excecutável */

		printf("MiniShell@WU_GUSTAVO %s:~$ ",getcwd(buf_pwd, 100)); /*imprime o caminho atual */
		get_cmd(cmd_buf,sizeof(cmd_buf)); /* lê do teclado e armazena em cmd_buf */
                if(strchr(cmd_buf,'&')!=0) /* se for rodar no background */
                {
                        bg_flag=1;
                        cmd_buf[strlen(cmd_buf)-2]='\0'; /* tira o '&' de cmd_buf */
                }
                if((cmd_buf[0]=='.')&&(cmd_buf[1]=='/')) /* se for um programa executável */
                {
                        exe_flag=1;
                }
		if(my_pipe(cmd_buf)) /* verifica se tem pipe */
			continue;
		redirect(cmd_buf,erg); /* coloca o conteúdo de cmd_buf como argumentos */

		if(fun_shell(i,erg)) /* se for comando interno */
		{
			reset_io();
			continue;
		}
		if((cmd_name=is_founded(erg[0]))||exe_flag==1) /* se for um comando implementado */
		{
                        exe_flag=0;
                        pid=fork();
                        if(pid < 0)
                        {
                                perror("fork");/*erro de criar processo filho*/
                                exit(1);
                        }
			else if(pid==0)
			{
				if(execv(cmd_name,erg)<0 && execv(erg[0],erg)<0)
				switch(errno){ /* tratamento de erros dos programas executáveis, acesso não permitido, etc. */
				case ENOENT:
					printf("COMMAND OR FILENAME NOT FOUND\n");
					break;
				case EACCES:
					printf("YOU DO NOT HAVE RIGHT TO ACCESS\n");
					break;
	                        default:
	                                printf("SOME ERROR HAPPENED IN EXEC\n");}
                                exit(3);
			}
                        else
                        {
                               int status;
                               if(bg_flag==0)/*se não for background,espera o término do  processo filho*/
                               {
                                        waitpid(pid,&status,WUNTRACED);
                               }
                               else
                              {
                                        bg_flag=0;/*se for background,seta o flag para 0*/
                                        status=123;/*123 é o número definido aqui para tratar background*/
                              }
                               add_job_node(status, pid, erg[0]);/*coloca o job na lista dos jobs*/
                        }
		}
		else/*comando inválido*/
		{
                                printf("command %s not found!\n",erg[0]);
				reset_io();/*limpar os bufferes do IO*/
				waitpid(pid,&status,0);/*espera terminar esse processo*/
                                
		}

	}

	return 0;

}
