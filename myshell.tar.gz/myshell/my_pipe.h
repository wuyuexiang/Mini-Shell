/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

#ifndef _MY_PIPE_H_
#define _MY_PIPE_H_

int my_pipe(char *cmd_buf);

#endif


