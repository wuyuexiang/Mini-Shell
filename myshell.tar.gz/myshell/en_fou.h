/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#ifndef _INCLUDE_EN_FOU_H_
#define _INCLUDE_EN_FOU_H_

void init_environ();
char *is_founded(char *cmd);

#endif
