/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

#ifndef _RECORD_HISTORY_H_H_
#define _RECORD_HISTORY_H_H_

void add_history(char *cmd);
int history(int key,char *cmd);
void history_list(int i);
void get_cmd(char *cmd,int size);

#endif
