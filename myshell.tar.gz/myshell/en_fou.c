/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include"en_fou.h"

static char env_buf[555]="";
char *env_argv[20]={NULL};
char cur_cmd[200]="";


void init_environ()/*define o perfil do ambiente*/
{	
	FILE *fp;
	if((fp=fopen("mysh_profile","r"))==NULL)//o arquivo mysh_profile tem nomes do diretório princiapl
	{                                       //de varios shells diferentes
		perror("open r");
		exit(1);
	}
	while(fgets(env_buf,sizeof(env_buf),fp))
	{
		env_buf[strlen(env_buf)-1]='\0';
		if(strncmp(env_buf,"PATH=",5)==0)/*garante que env_buf pegou a frase do arquivo*/
		{
			int i=0;
                        //dividir o resto em vários argumentos
			env_argv[i++]=strtok(env_buf+5,":");
			while((env_argv[i++]=strtok(NULL,":"))!=NULL);
		}
	}
	fclose(fp);
}

char *is_founded(char *cmd)/* verifica se ocoamndo for interno(implementado) ou não */
{
	int i=0;
	while(env_argv[i]!=NULL)/* para todos os argumentos */
	{	
		sprintf(cur_cmd,"%s/%s",env_argv[i],cmd);
		if(access(cur_cmd,F_OK)==0)/* verifica permissões */
		{
			return cur_cmd;/*retorna o comando*/
		}

		i++;
	}
	return NULL;
}
