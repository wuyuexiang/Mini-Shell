/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "en_fou.h"

static char env_buf[555]="";
char *env_argv[20]={NULL};
char cur_cmd[200]="";

/*!
    \brief Define o perfil do ambiente
*/
void init_environ()
{	
	FILE *fp;  
    /// Abre o arquivo mysh_profile, que tem o caminho do diretório principal.
	if((fp=fopen("mysh_profile","r"))==NULL)
	{
		perror("open r");
		exit(1);
	}
	while(fgets(env_buf,sizeof(env_buf),fp))
	{
		env_buf[strlen(env_buf)-1]='\0';
        /// Garante que env_buf pegou o caminho do arquivo.
		if(strncmp(env_buf,"PATH=",5)==0)
		{
            /// Dividir os outros argumentos.
			int i=0;
			env_argv[i++]=strtok(env_buf+5,":");
			while((env_argv[i++]=strtok(NULL,":"))!=NULL);
		}
	}
	fclose(fp);
}

/*!
    \brief Verifica se o comando é interno (implementado) ou não
    \return Retorna o comando 
*/
char *is_founded(char *cmd)
{
	int i=0;
	while(env_argv[i]!=NULL) /// Verifica permissões para todos os argumentos.
	{	
		sprintf(cur_cmd,"%s/%s",env_argv[i],cmd);
		if(access(cur_cmd,F_OK)==0)
		{
			return cur_cmd;
		}

		i++;
	}
	return NULL;
}
