/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include "redirect.h"

int fd_bak[2]={100,101};

int redirect(char *str, char *argv[])/*verifica se tem redirecionamento ou não*/

{
	char *p=str;
	char *wfile=NULL;
	char *rfile=NULL;
	int rfd,wfd;
	int i=0;
	unsigned int wflags=O_WRONLY|O_CREAT;/* flag: apenas escrita | cria se não existir */
	while((*p==' ')||(*p=='\t')) p++;
	argv[i++]=p;
	while(*p!='\0')
	{
		switch(*p)
		{
			case '>': /* trata > */
				if(argv[i-1]==p)
					i--;
				*p++='\0';
				if(*p=='>')
				{
					wflags |=O_APPEND;/* flag: coloca cursor no fim do arquivo */
					p++;
				}
				while((*p==' ')||(*p=='\t')||(*p=='>')) p++;
				wfile=p;
				break;
			case '<': /* trata < */
				if(argv[i-1]==p)
					i--;
				*p++='\0';
				while((*p==' ')||(*p=='\t')||(*p=='>')) p++;
				rfile=p;
				break;
			case ' ':
			case '\t':
			case '\'':
			case '"':
				*p='\0';
				p++;
				while((*p==' ')||(*p=='\t')||(*p=='\'')||(*p=='"')) p++;
				if((*p!='>')&&(*p!='<')&&(*p!=' ')&&(*p!=0))
					argv[i++]=p;
				break;
			default:
				p++;
				break;
		}
	}
	if(wfile!=NULL)
	{
		if((wfd=open(wfile,wflags,0666))<0)/* abre arquivo de escrita com as flags definidas acima */
		{
			perror("open write file");
			exit(1);
		}
		dup2(1,fd_bak[1]);/* substitui fd_bak[1] com o output padrão */
		dup2(wfd,1);/* substitui o output padrão com wfd */
		close(wfd);
	}
	
	if(rfile!=NULL)
	{
		if((rfd=open(rfile,O_RDONLY,0666))<0)/* abre arquivo de leitura */
		{
			perror("open read file");
			exit(1);
		}
		dup2(0,fd_bak[0]);/* substitui fd_bak[0] com o input padrão */
		dup2(rfd,0);/* substitui o input padrão com rfd */
		close(rfd);

	}
	return i;
	
}

int reset_io()
{
	dup2(fd_bak[1],1);/* substitui o output padrão com fd_bak[1] */
	dup2(fd_bak[0],0);/* substitui o input padrão com fd_bak[0] */
	return 0;
}


