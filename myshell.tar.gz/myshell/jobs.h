/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#ifndef __JOBS_INCLUDE_
#define	__JOBS_INCLUDE_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include<sys/wait.h>
extern int fg_pid;
extern int bg_pid;

typedef struct NODE
{
	int num;
	pid_t pid;
	char cmd[100];
	char state[10];
	struct NODE *next;
}NODE;

void add_job_node(int status, pid_t pid , char *cmd_name);
void del_node(void);	
void sig_init(void);
void bg_fun(char *job_num);
void jobs_fun(void);
void fg_fun(char *job_num);

#endif	/* __JOBS_INCLUDE_ */
