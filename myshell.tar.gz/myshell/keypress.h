/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#ifndef _INCLUDE_KEYPRESS_H_
#define _INCLUDE_KEYPRESS_H_

#include <termios.h>

void set_keypress(void);
void reset_keypress(void);

#endif  //_INCLUDE_KEYPRESS_H_
