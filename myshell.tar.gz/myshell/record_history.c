/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include"keypress.h"

typedef struct ENV_HISTORY/*estrutura de histórico*/
{
	int start;
	int end;
	char his_cmd[120][100];/*o hitórico é um vetor de string*/
}ENV_HISTORY;
ENV_HISTORY envhis={0,0,{""}};/*incialização de estrutura*/
 
int cur_his_num=0;

void add_history(char *cmd)
{
	memset(envhis.his_cmd[envhis.end],0,100);/*inicializa os históricos com nulo*/
	strcpy(envhis.his_cmd[envhis.end],cmd);/* adiciona comando no vetor de histórico */
	envhis.end=(envhis.end+1)%120;/*o histórico tem tamanho 120,divide ele pega o final do histórico para adicionar*/
	if(envhis.end==envhis.start)/*s final igual ao começo,incrementa o começo*/
	{
		envhis.start=(envhis.start+1)%120;
	}
	cur_his_num=envhis.end;/*setar a posiçao atual no fianl do histórico*/

}

int history(int key,char *cmd)/*função que mostra o histórico apertando as setas do teclado*/
{
	char cur_dir[100];
        char buf_pwd[100]=""; /* armazena o PATH */
	getcwd(cur_dir,sizeof(cur_dir));
	if(key==65)/*seta para cima,mostra os conteúdos anteriores de baixo para cima a partir da posição atual*/
	{
                if(cur_his_num!=envhis.start)/*se não fosse o topo*/
		{
			
                        cur_his_num--;
			memset(cmd,0,100);
			strcpy(cmd,envhis.his_cmd[cur_his_num]);
		}
	}
	else if(key==66)/*seta para baixo,mostra os conteúdos anteriores de cima para baixo a partir da posição atual*/
	{
		if(cur_his_num!=envhis.end)/*se fosse o fim*/
		{
			cur_his_num++;
			memset(cmd,0,100);
			strcpy(cmd,envhis.his_cmd[cur_his_num]);
		}
	
	}
	printf("\r\033[2K%s %s:~$ ","MiniShell@WU_GUSTAVO",getcwd(buf_pwd, 100));/*limpa o que tem no terminal e reimprime o caminho*/
	printf("%s",cmd);/*imprime o comando no histórico*/
	return 1;
}

void history_list(int i)/*listar o histórico*/
{
       while(i<envhis.end)
       {
              printf("%5d  %s\n",i,envhis.his_cmd[i]);
              i++;
       }
}

void get_cmd(char *cmd,int size)/*lê as teclas do teclado e analisa as*/
{	
	int i=0;
	set_keypress();/*ler o teclado*/
	while(1)
	{
		char ch;
		ch=getchar();
		if(ch==27)//history key
		{
			getchar();
			ch=getchar();
			history(ch,cmd);
			i=strlen(cmd);
		}
                else if(ch==26)/*ctrl_z*/
                {
                        ch=getchar();
                         continue;
                }
                else if(ch==3)/*ctrl_c*/
                {
                        ch=getchar();
                }
		else if(ch=='\n')
		{
			cmd[i]='\0';
			break;
		}
		else if(ch==127)//backspace key
		{
			if(i!=0)
			{
				i--;
				cmd[i]='\0';
				printf("%s","\b \b");
			}
		}
		else//fora as de cima,entenda com comando*/
		{
			write(1,&ch,1);
			cmd[i++]=ch;
		}
	}
	reset_keypress();/*setar as mudanças imediatamente*/
	printf("\n");
	cmd[strlen(cmd)+1]='\0';/*fim do string*/
	add_history(cmd);/*coloca no histórico*/
		
}
