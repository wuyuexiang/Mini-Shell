/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "keypress.h"

/*
  \typedef struct ENV_HISTORY
    \brief Estrutura de histórico
*/
typedef struct ENV_HISTORY
{
    int start;
    int end;
    char his_cmd[120][100]; /*! Vetor de string de histórico */
}ENV_HISTORY;

/*
  \typedef ENV_HISTORY envhis
    \brief Inicialização da estrutura
*/
ENV_HISTORY envhis={0,0,{""}};
 
int cur_his_num=0;

/*!
    \brief Adiciona comando digitado ao histórico
*/
void add_history(char *cmd)
{
    /// Inicializa os históricos com nulo.
    memset(envhis.his_cmd[envhis.end],0,100);
    /// Adiciona comando no vetor de histórico.
    strcpy(envhis.his_cmd[envhis.end],cmd);
    /// Como tem tamanho 120, divide-o e adiciona ao final dele.
    envhis.end=(envhis.end+1)%120;
    /// Se final igual ao começo, incrementa o começo.
    if(envhis.end==envhis.start)
    {
        envhis.start=(envhis.start+1)%120;
    }
    /// Seta a posiçao atual no fianl do histórico.
    cur_his_num=envhis.end;

}

/*!
    \brief Mostra o histórico apertando up e down no teclado
    \var char buf_pwd[100]
      \brief Armazena o PATH
*/
int history(int key,char *cmd)
{
    char cur_dir[100];
    char buf_pwd[100]="";
    getcwd(cur_dir,sizeof(cur_dir));
    /// Se UP_ARROW, mostra os conteúdos anteriores de baixo para cima a partir da posição atual.
    if(key==65)
    {
        /// Possível enquanto não for o início.
        if(cur_his_num!=envhis.start)
    {
                        cur_his_num--;
            memset(cmd,0,100);
            strcpy(cmd,envhis.his_cmd[cur_his_num]);
        }
    }
    /// Se DOWN_ARROW, mostra os conteúdos anteriores de cima para baixo a partir da posição atual
    else if(key==66)
    {
        /// Possível enquanto não for o for o fim.
        if(cur_his_num!=envhis.end)
        {
            cur_his_num++;
             memset(cmd,0,100);
            strcpy(cmd,envhis.his_cmd[cur_his_num]);
        }
    
    }
    /// Limpa o que tem no terminal e reimprime o caminho.
    printf("\r\033[2K%s %s:~$ ","MiniShell@WU_GUSTAVO",getcwd(buf_pwd, 100));
    /// Imprime o comando no histórico.
    printf("%s",cmd);
    return 1;
}

/*!
    \brief Listar o histórico
*/
void history_list(int i)
{
    while(i<envhis.end)
    {
        printf("%5d  %s\n",i,envhis.his_cmd[i]);
        i++;
    }
}

/*!
    \brief Lê as teclas do teclado e analisa-as
*/
void get_cmd(char *cmd,int size)
{    
    int i=0;
    /// Lê do teclado.
    set_keypress();
    while(1)
    {
        char ch;
        ch=getchar();
        /// Se RIGHT_ARROW.       
        if(ch==27)
        {
            getchar();
            ch=getchar();
            history(ch,cmd);
            i=strlen(cmd);
        }
        /// Senão, se CRTZ + Z.
        else if(ch==26)
        {
                ch=getchar();
                continue;
        }
        /// Senão, se CRTL + C.
        else if(ch==3)
        {
            ch=getchar();
        }
        /// Senão, se ENTER.
        else if(ch=='\n')
        {
            cmd[i]='\0';
            break;
        }
        /// Senão, se BACKSPACE.
        else if(ch==127)
        {
            if(i!=0)
            {
                i--;
                cmd[i]='\0';
                printf("%s","\b \b");
            }
        }
        /// Senão for nenhuma tecla acima mencionada, continue.
        else
        {
            write(1,&ch,1);
            cmd[i++]=ch;
        }
    }
    /// Seta as mudanças imediatamente.
    reset_keypress();
    printf("\n");
    /// Chega ao fim da string.
    cmd[strlen(cmd)+1]='\0';
    /// Coloca no histórico.  
    add_history(cmd);
        
}
