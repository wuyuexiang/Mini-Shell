/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#ifndef _REDIRECT_H_H_
#define _REDIRECT_H_H_
int redirect(char *str,char *argv[]);

int reset_io();

#endif 
