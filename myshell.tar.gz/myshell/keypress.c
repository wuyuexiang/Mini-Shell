/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#include "keypress.h"

static struct termios stored_settings;

void set_keypress(void)/*define o modo de caracter por caracter do teclado*/
{
    struct termios new_settings;

    tcgetattr(0,&stored_settings);/*setar os parâmetros associados com o terminal*/

    new_settings = stored_settings;

    /* Desativa modo canônico, e define o tamanho do buffer para 1 byte */
    new_settings.c_lflag &= ~(ICANON | ECHO);
    new_settings.c_cc[VTIME] = 0;
    new_settings.c_cc[VMIN] = 1;

    tcsetattr(0,TCSANOW,&new_settings);
    return;
}

void reset_keypress(void)/*resetar o teclado*/
{
    tcsetattr(0,TCSANOW,&stored_settings);/*a mudaça ocorre imediatamente*/
    return;
}
