/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

#include "keypress.h"

static struct termios stored_settings;

/*!
    \brief Define o modo para pegar caracter por caracter do teclado
*/
void set_keypress(void)
{
    struct termios new_settings;
    /// Setar os parâmetros associados com o terminal.
    tcgetattr(0,&stored_settings);

    new_settings = stored_settings;

    /// Desativa modo canônico, e define o tamanho do buffer para 1 byte.
    new_settings.c_lflag &= ~(ICANON | ECHO);
    new_settings.c_cc[VTIME] = 0;
    new_settings.c_cc[VMIN] = 1;

    tcsetattr(0,TCSANOW,&new_settings);
    return;
}

/*!
    \brief Resetar o teclado
*/
void reset_keypress(void)
{
    /// Mudança ocorre imediatamente.
    tcsetattr(0,TCSANOW,&stored_settings);
    return;
}
