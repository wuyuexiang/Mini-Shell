/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "order_judge.h"
#include "record_history.h"
#include "jobs.h"

char OLD_DIR[100]="";

typedef int(*cmd_fun_t)(int argc,char *argv[]);

/*!
  \typedef struct cmd_info
    \brief Estrutura que pega o nome e a respectiva função do comando
*/
typedef struct cmd_info
{
    char *cmd_name;
    cmd_fun_t fun;
}CMD_STRUCT,pCMD_STRUCT;

/*!
    \brief Comando cd
*/
int cd_fun(int argc,char *argv[])
{    
    char *dir=argv[1];
    char buf[100]="";
        
    if(strcmp(argv[1],"-")==0)        
    {
        strcpy(buf,OLD_DIR);
        dir=buf;
    }
    else if(strcmp(argv[1],"~")==0)
    {
        dir=getenv("HOME");
    }
    getcwd(OLD_DIR,100);
    chdir(dir);
    return 0;
}

/*!
    \brief Comando exit
*/
int exit_fun(int argc,char*argv[])
{    
    printf("Byebye!\n");
    exit(1);
}

/*!
    \brief Comando pause
*/
int pause_fun(int argc,char*argv[])
{                                       
        getpass("Pause!\npress <Enter> key to continue...");
        return 0;                                                 
}

/*!
    \brief Comando Help
*/
int help_fun(int argc,char*argv[])
{
        FILE *help;
        char array[max_buf];
        char keywords [max_buf]="<help ";   
    int i,len; 
    for(i=1;argv[i];i++)
    {
          strcat(keywords,argv[i]);
          strcat(keywords," ");
    }
     len=strlen(keywords);
     keywords[len-1]='>';
     keywords[len]='\0';
        /// Abre o arquivo de ajuda.
        help=fopen("help","r");
        /// Procura por palavras-chave.
        while(!feof(help)&&fgets(array,max_buf,help))
            {      
                if(strstr(array,keywords)) 
                          break;
                } 
        while(!feof(help)&&fgets(array,max_buf,help))
                {
                if(array[0]=='#')
              break;
                fputs(array,stdout);
                }
        /// Se o arquivo ainda estiver aberto quando a função for retornar, fechá-lo.
        if(help)
                fclose(help);
        return 0;
}

/*!
    \brief Comando jobs
*/
int job_fun(int argc,char*argv[])
{
        jobs_fun();
        return 0;
}

/*!
    \brief Comando history
*/
int history_fun(int argc,char*argv[])
{
        int i=0;
       
        history_list(i);

        return 0;
}

/*!
    \brief Comando fg
*/
int fgs_fun(int argc,char*argv[])
{       if(argv[1]!=NULL)
        fg_fun(argv[1]);
        else 
        fg_fun("1");    
        return 0;
}

/*!
    \brief Comando bg
*/
int bgs_fun(int argc,char*argv[])
{       if(argv[1]!=NULL)
        bg_fun(argv[1]);
        else 
        bg_fun("1");    
        return 0;
}

/*!
  \typef CMD_STRUCT cmd_list
    \brief Lista dos comandos implementados
*/
CMD_STRUCT cmd_list[]={
        {"cd",cd_fun},
        {"exit",exit_fun},
                {"help",help_fun},
                {"history",history_fun},
                {"pause",pause_fun},
                {"jobs",job_fun},
                {"fg",fgs_fun},
        {"bg",bgs_fun}
};

/*!
    \brief Executa o comando digitado (se válido)
    \return Se válido, retorna 1, 0 caso contrário
*/
int fun_shell(int argc,char *argv[])
{    

    int i=0;
    int cmd_num=sizeof(cmd_list)/sizeof(CMD_STRUCT);
    while(i<cmd_num)
    {
        if(strcmp(cmd_list[i].cmd_name,argv[0])==0)
        {
            cmd_list[i].fun(argc,argv);
            return 1;
        }
        i++;    
    }    

    return 0;
}


