/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include"order_judge.h"
#include"record_history.h"
#include"jobs.h"

char OLD_DIR[100]="";

typedef int(*cmd_fun_t)(int argc,char *argv[]);

typedef	struct cmd_info/*estrutura que pega o nome e a respectiva função do comando*/
{
	char *cmd_name;
	cmd_fun_t fun;
}CMD_STRUCT,pCMD_STRUCT;

int cd_fun(int argc,char *argv[])/* comando cd */
{	
	char *dir=argv[1];
	char buf[100]="";
        
	if(strcmp(argv[1],"-")==0)		
	{
		strcpy(buf,OLD_DIR);
		dir=buf;
	}
	else if(strcmp(argv[1],"~")==0)
	{
		dir=getenv("HOME");
	}
	getcwd(OLD_DIR,100);
	chdir(dir);/* muda de diretório */
	return 0;
}

int exit_fun(int argc,char*argv[]) /* comando exit */
{	
	printf("Byebye!\n");
	exit(1);
}

int pause_fun(int argc,char*argv[]) /* comando pause */
{                                       
        getpass("Pause!\npress <Enter> key to continue...");
        return 0;                                                 
}

int help_fun(int argc,char*argv[]) /* comando help */
{
        FILE *help;
        char array[max_buf];
        char keywords [max_buf]="<help ";   
	int i,len; 
	for(i=1;argv[i];i++)
	{
	      strcat(keywords,argv[i]);
	      strcat(keywords," ");
	}
	 len=strlen(keywords);
	 keywords[len-1]='>';
	 keywords[len]='\0';
     
        help=fopen("help","r");
        while(!feof(help)&&fgets(array,max_buf,help)) /* procurando por palavras-chave */
	        {      
                if(strstr(array,keywords)) 
                          break;
                } 
        while(!feof(help)&&fgets(array,max_buf,help))
                {
                if(array[0]=='#')
			  break;
                fputs(array,stdout);
                }
         
        if(help)/*se o arquivo tivesse aberto,feche o*/
                fclose(help);
        return 0;
}
int job_fun(int argc,char*argv[]) /* comando jobs */
{
        jobs_fun();
        return 0;
}
int history_fun(int argc,char*argv[]) /* comando history */
{
        int i=0;
       
        history_list(i);

        return 0;
}
int fgs_fun(int argc,char*argv[]) /* comando fg */
{       if(argv[1]!=NULL)
		fg_fun(argv[1]);
        else 
		fg_fun("1");	
        return 0;
}
int bgs_fun(int argc,char*argv[]) /* comando bg */
{       if(argv[1]!=NULL)
		bg_fun(argv[1]);
        else 
		bg_fun("1");	
        return 0;
}
CMD_STRUCT cmd_list[]={/*a lista dos comandos implementados*/
		{"cd",cd_fun},
		{"exit",exit_fun},
                {"help",help_fun},
                {"history",history_fun},
                {"pause",pause_fun},
                {"jobs",job_fun},
                {"fg",fgs_fun},
		{"bg",bgs_fun}
};

int fun_shell(int argc,char *argv[])/*excecuta o comando digitado válido*/
{	

	int i=0;
	int cmd_num=sizeof(cmd_list)/sizeof(CMD_STRUCT);
	while(i<cmd_num)
	{
		if(strcmp(cmd_list[i].cmd_name,argv[0])==0)
		{
			cmd_list[i].fun(argc,argv);
			return 1;
		}
		i++;
		
	}	
	
	return 0;
}


