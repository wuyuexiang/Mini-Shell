/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */    

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "my_pipe.h"
#include <wait.h>
#include "redirect.h"
#include "en_fou.h"

/*!
    \brief Verifica se há pipe ou não 
    \return 1 se há pipe, 0 se não há pipe
*/
int my_pipe(char *cmd_buf)
{
    int fds[2];
    char *tbuf[100]={NULL};
    char *p=NULL,*out_cmd=NULL;
    if((p=strstr(cmd_buf,"|")))
    {
        *p='\0';
         if(pipe(fds)==-1)
        {
            perror("pipe");
            exit(1);
        
        }
        /// Se fork = 0 (processo filho).
        if(fork()==0)
        {    
            redirect(cmd_buf,tbuf);
            /// Substitui o output padrão por fds[1].
            dup2(fds[1],1);
            close(fds[0]);
            if((out_cmd=is_founded(tbuf[0]))==NULL)
                exit(1);
            /// Executa se o comando estiver implementado.
            execv(out_cmd,tbuf);
        }
        else
        {
            /// Senão, se fork = 0 (processo filho). 
            if(fork()==0)
            {    
                redirect(p+1,tbuf);
                /// Substitui o input padrão por fds[0].
                dup2(fds[0],0);
                close(fds[1]);
                if((out_cmd=is_founded(tbuf[0]))==NULL)
                exit(1);
                /// Executa se o comando estiver implementado.
                execv(out_cmd,tbuf);
            }
            /// Senão, processo pai.
            else
            {    
                close(fds[0]);
                close(fds[1]);
                wait(NULL);
                wait(NULL);
                reset_io();
            }
        }
    return 1;
    }
    else
         return 0;        
}

