/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include"my_pipe.h"
#include<wait.h>
#include"redirect.h"
#include"en_fou.h"

int my_pipe(char *cmd_buf)/*verifica se tem pipe ou não*/
{
	int fds[2];
	char *tbuf[100]={NULL};
	char *p=NULL,*out_cmd=NULL;
	if((p=strstr(cmd_buf,"|")))
	{
		*p='\0';
	 	if(pipe(fds)==-1)
		{
			perror("pipe");
			exit(1);
		
		}
		if(fork()==0) /* processo filho */
		{	
			redirect(cmd_buf,tbuf);
			dup2(fds[1],1);/* substitui o output padrão com fds[1] */
			close(fds[0]);
			if((out_cmd=is_founded(tbuf[0]))==NULL)
				exit(1);
			execv(out_cmd,tbuf);/* executa se o comando estiver implementado */
		}
		
		else
		{	
			if(fork()==0)
			{	
				redirect(p+1,tbuf);
				dup2(fds[0],0);/* substitui o input padrão com fds[0] */
				close(fds[1]);
				if((out_cmd=is_founded(tbuf[0]))==NULL)
				exit(1);
				execv(out_cmd,tbuf);/* executa se o comando estiver implementado */
			
			
			}
			else/* processo pai */
			{	
				close(fds[0]);
				close(fds[1]);
				wait(NULL);
				wait(NULL);
				reset_io();
		
			}
		
		}
	return 1;
	}
		
	else
		 return 0;
		
		
}

