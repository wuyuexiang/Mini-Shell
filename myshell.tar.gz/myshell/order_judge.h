/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#ifndef _ORDER_JUDGE_H_
#define _ORDER_JUDGE_H_


int fun_shell(int argc,char *argv[]);

#endif

#define max_buf 1024
