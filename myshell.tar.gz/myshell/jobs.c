/**
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */
#include"jobs.h"

NODE *head,*end,*p,*q;

int fg_pid=0;

void ctrl_z() /* ctrl+z */
{
	
	NODE *p;
	p=head;
	while(p!=NULL)
	{
		if((*(p->state)=='R')&&(p->pid!=fg_pid))
		{
				kill(p->pid,SIGCONT);
		}
		p=p->next;
	}
        	
}

void ctrl_c() /* ctrl+c */
{
        del_node();/*remove o job na lista*/	
}


void sig_init()/*inicializa os sinais*/
{
	signal(SIGTSTP, ctrl_z);
	signal(SIGINT, ctrl_c);
        head=end=p=q=NULL;	
	
}

NODE *find_node(pid_t pid)/*achar o job*/
{
	NODE *p;
	p=head;
	while(p!=NULL)
	{
		if(p->pid==pid)
		{
			/* printf("find pid in node\n"); */
			return p;
		}	
		p=p->next;
	}	
	return NULL;
}

void del_node(void)/*deletar um job na lista*/
{
	NODE *p,*q;
	p=head;
	while(p!=NULL)
	{
		q=p->next;
		printf("(strchr(cmd_buf,'&')!=0)\n");
		free(p);
		p=q;
	}
	head=NULL;
}
void add_job_node(int status, pid_t pid , char *cmd_name)/*adicionar um job na lista*/
{
	int bg_cmd=0;
	if(status == 123)/*o número definido para verificar-se for background ou não*/
	{		
		bg_cmd=1;
	}	
	else if( !WIFSTOPPED(status) )
		return;	
	p=(struct NODE *)malloc(sizeof(struct NODE));
	if(head==NULL)/*adicionar o primeiro job na lista*/
	{
		/* printf("this is the frist jobs node\n"); */
		head=end=p;
		p->num=1;
	}
	else
	{
		NODE *find_job;
		if((find_job=find_node(pid))==NULL)/*se fosse um novo processo*/			
		{
			end->next=p;
			p->num=end->num+1;		
			end=p;
		}
		else/*se não setar o status desse processo como parado*/
		{
			p=find_job;
			strcpy(p->state,"Stopped\0");
			printf("[%d]+ %s		%s\n",end->num,end->state,end->cmd);
			return;
		}	
	}
	p->pid=pid;
	strcpy(p->cmd,cmd_name);
	if(bg_cmd==1)		/* cmd with ' & ' */
	{
		bg_cmd = 0;
		strcpy(p->state,"Running...\0");
	}	
	else						/* ctrl+z */
	{
		strcpy(p->state,"Stopped\0");
                         printf("\n[%d]+ %s		%s\n",end->num,end->state,end->cmd);
	}
	p->next=NULL;
	
}

void jobs_fun()/*listra todos os jobs na lista*/
{
	NODE *p_jobs;
	p_jobs=head;
	while(p_jobs!=NULL)
	{
		printf("[%d]+ %s		%s\n",p_jobs->num,p_jobs->state,p_jobs->cmd);
		p_jobs=p_jobs->next;
	}
}

void bg_fun(char *job_num) /* coloca processo em background */
{
	NODE *p_jobs;
	p_jobs=head;
	while(p_jobs!=NULL)
	{
		if(p_jobs->num == atoi(job_num))
		{
			/* printf("found %d job\n",p_jobs->num); */
			strcpy(p_jobs->state,"Running\0");
			kill(p_jobs->pid, SIGCONT);
			/* printf("%s is %s...\n",p_jobs->cmd,p_jobs->state); */
			break;	
		}
		p_jobs=p_jobs->next;
	}	
	if(p_jobs==NULL)
		printf("no this jobs\n");
}

void fg_fun(char *job_num) /* coloca processo em foreground */
{
	NODE *p_jobs;
	p_jobs=head;
	while(p_jobs!=NULL)
	{
		if(p_jobs->num == atoi(job_num))
		{
			int status;
			strcpy(p_jobs->state,"Running\0");
			kill(p_jobs->pid, SIGCONT);			
			fg_pid = p_jobs->pid;
                        printf("%s\n",p_jobs->cmd);
			waitpid(p_jobs->pid,&status,WUNTRACED);
			add_job_node(status,p_jobs->pid,p_jobs->cmd);
			break;
		}
		p_jobs=p_jobs->next;
	}	
	if(p_jobs==NULL)
		printf("no this jobs\n");
}
