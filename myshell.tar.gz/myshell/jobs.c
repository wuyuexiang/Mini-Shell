/*
 * Universidade de São Paulo
 * Sistemas Operacionais 2
 * Implementação de um mini shell
 *
 *  Wu Yuexiang          6792502
 *  Gustavo Shinji Inoue 6878758
 */

#include "jobs.h"

NODE *head,*end,*p,*q;

int fg_pid=0;

/*!
    \brief CTRL + Z
*/
void ctrl_z()
{
    
    NODE *p;
    p=head;
    while(p!=NULL)
    {
        if((*(p->state)=='R')&&(p->pid!=fg_pid))
        {
                kill(p->pid,SIGCONT);
        }
        p=p->next;
    }
            
}

/*!
    \brief CTRL + C
*/
void ctrl_c()
{
        /// Remove o job na lista.
        del_node();
}

/*!
    \brief Inicializa os sinais.
*/
void sig_init()
{
    signal(SIGTSTP, ctrl_z);
    signal(SIGINT, ctrl_c);
        head=end=p=q=NULL;    
    
}

/*!
    \brief Achar o job
    \return Retorna o pid do nó
*/
NODE *find_node(pid_t pid)
{
    NODE *p;
    p=head;

    while(p!=NULL)
    {
        if(p->pid==pid)
        {
            /* printf("find pid in node\n"); */
            return p;
        }    
        p=p->next;
    }    
    return NULL;
}

/*!
    \brief Deletar um job na lista
*/
void del_node(void)
{
    NODE *p,*q;
    p=head;
    while(p!=NULL)
    {
        q=p->next;
        printf("\n");
        free(p);
        p=q;
    }
    head=NULL;
}

/*!
    \brief Adicionar um job na lista
*/
void add_job_node(int status, pid_t pid , char *cmd_name)
{
    int bg_cmd=0;
    /// Verifica se status = 123, flag que indica se o processo rodará no background ou não.
    if(status == 123)
    {        
        bg_cmd=1;
    }    
    else if( !WIFSTOPPED(status) )
        return;    
    p=(struct NODE *)malloc(sizeof(struct NODE));
    /// Se cabeça = NULL, adiciona o primeiro job na lista.
    if(head==NULL)
    {
        /* printf("this is the first jobs node\n"); */
        head=end=p;
        p->num=1;
    }
    else
    {
        NODE *find_job;
        /// Se for um novo processo, adiciona no final da lista.
        if((find_job=find_node(pid))==NULL)        
        {
            end->next=p;
            p->num=end->num+1;        
            end=p;
        }
        /// Senão, setar o status do processo como STOPPED.
        else
        {
            p=find_job;
            strcpy(p->state,"Stopped\0");
            printf("[%d]+ %s        %s\n",end->num,end->state,end->cmd);
            return;
        }    
    }
    p->pid=pid;
    strcpy(p->cmd,cmd_name);
    /// Se for encontrado um &, inicializa processo no background.
    if(bg_cmd==1)
    {
        bg_cmd = 0;
        strcpy(p->state,"Running...\0");
    }
    /// Senão, para o processo.
    else
    {
        strcpy(p->state,"Stopped\0");
                         printf("\n[%d]+ %s        %s\n",end->num,end->state,end->cmd);
    }
    p->next=NULL;
    
}

/*!
    \brief Lista todos os jobs na lista
*/
void jobs_fun()
{
    NODE *p_jobs;
    p_jobs=head;
    while(p_jobs!=NULL)
    {
        printf("[%d]+ %s        %s\n",p_jobs->num,p_jobs->state,p_jobs->cmd);
        p_jobs=p_jobs->next;
    }
}

/*!
    \brief Coloca processo em background
*/
void bg_fun(char *job_num)
{
    NODE *p_jobs;
    p_jobs=head;
    while(p_jobs!=NULL)
    {
        if(p_jobs->num == atoi(job_num))
        {
            /* printf("found %d job\n",p_jobs->num); */
            strcpy(p_jobs->state,"Running\0");
            kill(p_jobs->pid, SIGCONT);
            /* printf("%s is %s...\n",p_jobs->cmd,p_jobs->state); */
            break;    
        }
        p_jobs=p_jobs->next;
    }    
    if(p_jobs==NULL)
        printf("Job not found\n");
}

/*!
    \brief Coloca processo em foreground
*/
void fg_fun(char *job_num)
{
    NODE *p_jobs;
    p_jobs=head;
    while(p_jobs!=NULL)
    {
        if(p_jobs->num == atoi(job_num))
        {
            int status;
            strcpy(p_jobs->state,"Running\0");
            kill(p_jobs->pid, SIGCONT);            
            fg_pid = p_jobs->pid;
                        printf("%s\n",p_jobs->cmd);
            waitpid(p_jobs->pid,&status,WUNTRACED);
            add_job_node(status,p_jobs->pid,p_jobs->cmd);
            break;
        }
        p_jobs=p_jobs->next;
    }    
    if(p_jobs==NULL)
        printf("Job not found\n");
}
